(function () {
  "use strict";
  window.EXAM_MASTER_LESSONS = window.EXAM_MASTER_LESSONS || {};
  window.EXAM_MASTER_LESSONS["JSS 1"] = window.EXAM_MASTER_LESSONS["JSS 1"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] =
    window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"]["Digital Technologies"] = [
  {
    "week": 1,
    "title": "Introduction to Information and Communication Technology (ICT)",
    "objectives": [
      "Explain ICT.",
      "Identify common uses of ICT.",
      "Describe responsible use of digital devices."
    ],
    "introduction": "ICT means Information and Communication Technology. It includes digital tools used to create, store, process and share information.",
    "sections": [
      {
        "heading": "Meaning of ICT",
        "content": "Information is meaningful facts or knowledge. Communication is sharing information. Technology includes tools and systems that help people perform tasks."
      },
      {
        "heading": "Examples of ICT Tools",
        "content": "Computers, tablets, smartphones, radios, televisions, printers and networks are examples of ICT tools."
      },
      {
        "heading": "Uses of ICT",
        "content": "ICT is used in education, banking, healthcare, farming, business, communication and public services. Learners may use digital tools to read, practise skills and prepare schoolwork."
      },
      {
        "heading": "Responsible Use",
        "content": "Use devices for suitable purposes, respect other people's work, protect private information and follow school and family rules."
      }
    ],
    "workedExamples": [
      {
        "question": "What does ICT stand for?",
        "solution": "Information and Communication Technology."
      },
      {
        "question": "Give two uses of ICT in education.",
        "solution": "Accessing learning materials and preparing schoolwork."
      }
    ],
    "keyTerms": [
      "ICT",
      "Information",
      "Communication",
      "Technology",
      "Digital device",
      "Responsible use"
    ],
    "classExercises": [
      "Write the full meaning of ICT. Answer: Information and Communication Technology.",
      "Name three ICT devices. Answer: Computer, tablet and smartphone.",
      "State one responsible-use rule. Answer: Protect private information and follow school rules."
    ],
    "commonMistakes": [
      "Thinking ICT means computers only; it includes many communication and information tools.",
      "Sharing private details carelessly online."
    ],
    "summary": "ICT tools help people create, process, store and communicate information. They should be used responsibly.",
    "examinationPractice": [
      {
        "question": "ICT stands for _____.",
        "answer": "Information and Communication Technology",
        "explanation": "This is the full form of ICT."
      },
      {
        "question": "Name one way ICT supports learning.",
        "answer": "Accessing lessons / practising skills / preparing schoolwork",
        "explanation": "Digital tools can support education."
      }
    ]
  },
  {
    "week": 2,
    "title": "Parts of a Computer",
    "objectives": [
      "Identify the main parts of a desktop computer.",
      "Describe the basic role of each part.",
      "Distinguish hardware from software."
    ],
    "introduction": "A computer is an electronic device that accepts data, processes it and produces information. A desktop computer has several connected parts.",
    "sections": [
      {
        "heading": "Main Parts",
        "content": "The system unit contains important internal components. The monitor displays information. The keyboard is used to enter text and commands. The mouse or touchpad controls the pointer."
      },
      {
        "heading": "Other Devices",
        "content": "Speakers produce sound, a printer produces paper copies and a scanner converts paper documents or images into digital form."
      },
      {
        "heading": "Hardware and Software",
        "content": "Hardware refers to physical parts that can be touched. Software refers to programs and instructions that tell the computer what to do."
      },
      {
        "heading": "Care of Computer Parts",
        "content": "Keep food and liquids away, handle cables carefully, keep devices clean and follow the teacher's instructions when switching equipment on or off."
      }
    ],
    "workedExamples": [
      {
        "question": "Which part displays text and pictures?",
        "solution": "The monitor."
      },
      {
        "question": "Is a word-processing program hardware or software?",
        "solution": "Software."
      }
    ],
    "keyTerms": [
      "Computer",
      "System unit",
      "Monitor",
      "Keyboard",
      "Mouse",
      "Hardware",
      "Software",
      "Printer"
    ],
    "classExercises": [
      "Name four parts of a desktop computer. Answer: System unit, monitor, keyboard and mouse.",
      "What is hardware? Answer: The physical parts of a computer.",
      "Give one example of software. Answer: A word processor or web browser."
    ],
    "commonMistakes": [
      "Calling the monitor the system unit.",
      "Describing software as a physical part that can be touched."
    ],
    "summary": "A computer has physical hardware and programs called software. Each part has a specific role.",
    "examinationPractice": [
      {
        "question": "The physical parts of a computer are called _____.",
        "answer": "Hardware",
        "explanation": "Hardware can be seen and touched."
      },
      {
        "question": "Which device is used mainly to enter text?",
        "answer": "Keyboard",
        "explanation": "The keyboard has keys for letters, numbers and commands."
      }
    ]
  },
  {
    "week": 3,
    "title": "Functions of Computer Parts",
    "objectives": [
      "Explain the functions of common computer parts.",
      "Identify input, processing, output and storage roles.",
      "Describe a simple computer work cycle."
    ],
    "introduction": "Computer parts work together. Data is entered, processed, presented as information and sometimes saved for later use.",
    "sections": [
      {
        "heading": "Input",
        "content": "Input devices send data or instructions to a computer. A keyboard enters text; a mouse selects items; a microphone captures sound; a scanner captures printed material."
      },
      {
        "heading": "Processing",
        "content": "The central processing unit (CPU) carries out instructions and processes data. It is often described as the computer's main processor."
      },
      {
        "heading": "Output",
        "content": "Output devices present results. A monitor displays information, speakers produce sound and a printer produces hard copies."
      },
      {
        "heading": "Storage",
        "content": "Storage devices keep files and information for later use. Examples include a computer drive, memory card and USB flash drive. Always follow safe handling instructions."
      }
    ],
    "workedExamples": [
      {
        "question": "A learner types a name using a keyboard. Is this input or output?",
        "solution": "Input."
      },
      {
        "question": "Which device produces a paper copy?",
        "solution": "A printer."
      }
    ],
    "keyTerms": [
      "Input",
      "Processing",
      "Output",
      "Storage",
      "CPU",
      "Hard copy",
      "Soft copy"
    ],
    "classExercises": [
      "What is the function of a CPU? Answer: It processes data and carries out instructions.",
      "Classify a speaker. Answer: Output device.",
      "Classify a keyboard. Answer: Input device."
    ],
    "commonMistakes": [
      "Confusing input devices with output devices.",
      "Thinking the CPU and the whole system unit are exactly the same thing."
    ],
    "summary": "Input devices enter data, the CPU processes it, output devices present results and storage keeps files.",
    "examinationPractice": [
      {
        "question": "A printer is an _____ device.",
        "answer": "Output",
        "explanation": "It presents computer information on paper."
      },
      {
        "question": "The CPU mainly performs _____.",
        "answer": "Processing",
        "explanation": "It carries out instructions and processes data."
      }
    ]
  },
  {
    "week": 4,
    "title": "Input and Output Devices",
    "objectives": [
      "Define input and output devices.",
      "Identify examples of each group.",
      "Classify common computer peripherals."
    ],
    "introduction": "Devices connected to a computer help users enter data and receive results. They are often grouped as input or output devices.",
    "sections": [
      {
        "heading": "Input Devices",
        "content": "A keyboard enters text, a mouse selects items, a microphone captures sound, a scanner captures images and a webcam captures video."
      },
      {
        "heading": "Output Devices",
        "content": "A monitor displays text and images, a printer makes paper copies, speakers produce sound and a projector displays images on a larger surface."
      },
      {
        "heading": "Devices with More Than One Role",
        "content": "Some modern devices can both receive and display information. A touchscreen can show output and detect touch as input."
      },
      {
        "heading": "Choosing a Device",
        "content": "Choose a device based on the task. Use a microphone to record sound and a printer when a paper copy is needed."
      }
    ],
    "workedExamples": [
      {
        "question": "Classify a webcam.",
        "solution": "Input device."
      },
      {
        "question": "Why can a touchscreen be both input and output?",
        "solution": "It displays information and detects the user's touch."
      }
    ],
    "keyTerms": [
      "Input device",
      "Output device",
      "Peripheral",
      "Touchscreen",
      "Webcam",
      "Projector"
    ],
    "classExercises": [
      "Name three input devices. Answer: Keyboard, mouse and microphone.",
      "Name three output devices. Answer: Monitor, printer and speakers.",
      "Explain why a touchscreen has two roles. Answer: It displays information and accepts touch input."
    ],
    "commonMistakes": [
      "Calling a printer an input device.",
      "Assuming every device has only one possible function."
    ],
    "summary": "Input devices send data to a computer. Output devices present results, and some devices perform both roles.",
    "examinationPractice": [
      {
        "question": "Which device captures sound for a computer?",
        "answer": "Microphone",
        "explanation": "A microphone is an input device."
      },
      {
        "question": "Which device displays information on a large screen or wall?",
        "answer": "Projector",
        "explanation": "A projector is an output device."
      }
    ]
  },
  {
    "week": 5,
    "title": "Keyboard Skills and Basic Typing",
    "objectives": [
      "Identify important groups of keyboard keys.",
      "Use correct basic typing habits.",
      "Practise entering and editing short text."
    ],
    "introduction": "The keyboard is an input device used to enter letters, numbers, symbols and commands.",
    "sections": [
      {
        "heading": "Groups of Keys",
        "content": "Alphabet keys enter letters. Number keys enter digits. The spacebar inserts spaces. Enter starts a new line or confirms an action. Backspace removes characters to the left of the cursor; Delete removes characters to the right in many applications."
      },
      {
        "heading": "Other Useful Keys",
        "content": "Shift helps type capital letters or upper symbols. Caps Lock changes letter case. Arrow keys move the cursor. Tab moves between fields or creates an indent in some programs."
      },
      {
        "heading": "Typing Habits",
        "content": "Sit comfortably, keep the keyboard at a suitable height and use gentle key presses. Practise accuracy before trying to increase speed."
      },
      {
        "heading": "Editing Text",
        "content": "Use the arrow keys or touchpad to place the cursor. Correct mistakes carefully and save work when the application allows it."
      }
    ],
    "workedExamples": [
      {
        "question": "Which key creates a space between words?",
        "solution": "The spacebar."
      },
      {
        "question": "Which key commonly removes the character to the left of the cursor?",
        "solution": "Backspace."
      }
    ],
    "keyTerms": [
      "Keyboard",
      "Spacebar",
      "Enter",
      "Backspace",
      "Delete",
      "Shift",
      "Caps Lock",
      "Cursor"
    ],
    "classExercises": [
      "What is the function of the spacebar? Answer: It inserts spaces between words.",
      "Which key helps type a capital letter while held down? Answer: Shift.",
      "Why practise accuracy before speed? Answer: Correct typing reduces errors and makes editing easier."
    ],
    "commonMistakes": [
      "Using Caps Lock when only one capital letter is needed.",
      "Pressing keys too hard or rushing before learning key positions."
    ],
    "summary": "Keyboard keys have different functions. Comfortable posture and accurate practice help develop typing skills.",
    "examinationPractice": [
      {
        "question": "The key used to insert spaces is the _____.",
        "answer": "Spacebar",
        "explanation": "It separates words."
      },
      {
        "question": "Which key removes the character before the cursor?",
        "answer": "Backspace",
        "explanation": "Backspace removes the character to the left."
      }
    ]
  },
  {
    "week": 6,
    "title": "Computer Storage Devices",
    "objectives": [
      "Explain computer storage.",
      "Identify common storage devices.",
      "Describe safe storage and file-handling habits."
    ],
    "introduction": "Storage is the keeping of digital information so that it can be used later. Computers use different types of storage.",
    "sections": [
      {
        "heading": "Primary and Secondary Storage",
        "content": "Primary memory is used by the computer while it is working. Secondary storage keeps files for longer periods, even when the computer is turned off."
      },
      {
        "heading": "Examples of Storage Devices",
        "content": "Hard disk drives and solid-state drives are used in computers. USB flash drives and memory cards are portable. Optical discs are another storage medium."
      },
      {
        "heading": "Files and Folders",
        "content": "A file stores information such as a document, picture or audio recording. A folder helps organise files into groups."
      },
      {
        "heading": "Safe Storage Habits",
        "content": "Use clear file names, keep backup copies where permitted, eject removable drives safely and do not open unknown files from untrusted sources."
      }
    ],
    "workedExamples": [
      {
        "question": "Which portable device can store and transfer files?",
        "solution": "A USB flash drive."
      },
      {
        "question": "Why are folders useful?",
        "solution": "They organise files so they are easier to find."
      }
    ],
    "keyTerms": [
      "Storage",
      "Primary memory",
      "Secondary storage",
      "Hard drive",
      "SSD",
      "USB flash drive",
      "Memory card",
      "File",
      "Folder"
    ],
    "classExercises": [
      "Name two portable storage devices. Answer: USB flash drive and memory card.",
      "What is a folder used for? Answer: Organising files.",
      "State one safe storage habit. Answer: Eject removable storage safely."
    ],
    "commonMistakes": [
      "Confusing a folder with a physical storage device.",
      "Removing a storage device while files are being saved."
    ],
    "summary": "Storage keeps digital information. Files and folders organise work, while careful handling protects it.",
    "examinationPractice": [
      {
        "question": "A USB flash drive is mainly used for _____.",
        "answer": "Portable storage",
        "explanation": "It can keep and transfer digital files."
      },
      {
        "question": "A folder helps a user _____.",
        "answer": "Organise files",
        "explanation": "Folders group related files together."
      }
    ]
  },
  {
    "week": 7,
    "title": "Introduction to the Internet and Safe Use",
    "objectives": [
      "Explain the internet in simple terms.",
      "Identify useful educational uses of the internet.",
      "Recognise basic online safety rules.",
      "Explain digital citizenship.",
      "Identify respectful and safe online behaviour.",
      "Describe ways to care for digital devices."
    ],
    "introduction": "The internet is a worldwide network that connects computers and other devices so they can share information and services.",
    "sections": [
      {
        "heading": "Uses of the Internet",
        "content": "People use the internet for learning, communication, research, news, maps and public information. Information should be checked before it is trusted."
      },
      {
        "heading": "Websites and Browsers",
        "content": "A website is a collection of related web pages. A web browser is an application used to visit websites."
      },
      {
        "heading": "Online Safety",
        "content": "Keep passwords and private details secret. Do not share your home address, school details or live location with strangers. Do not meet an online contact without a trusted adult's knowledge."
      },
      {
        "heading": "Respectful Use",
        "content": "Be polite online, respect copyright, avoid spreading rumours and tell a trusted adult if a message or online interaction makes you uncomfortable."
      },
      {
        "heading": "Respectful Communication",
        "content": "Use polite language, avoid bullying, respect other people's opinions and think before posting or forwarding messages."
      },
      {
        "heading": "Privacy and Security",
        "content": "Keep passwords private, use device locks where permitted, ask before sharing another person's photo or work and avoid unknown links or downloads."
      },
      {
        "heading": "Copyright and Honesty",
        "content": "Give credit when using another person's work. Do not copy assignments and present them as your own. Use content only when you have permission or it is allowed for the task."
      },
      {
        "heading": "Device Care",
        "content": "Keep devices dry and clean, carry them carefully, avoid pulling cables and report faults to a responsible adult. Follow school rules for shared equipment."
      }
    ],
    "workedExamples": [
      {
        "question": "What is a web browser used for?",
        "solution": "It is used to visit and view websites."
      },
      {
        "question": "What should you do if an online message makes you uncomfortable?",
        "solution": "Stop responding and tell a trusted adult."
      }
    ],
    "keyTerms": [
      "Internet",
      "Network",
      "Website",
      "Web page",
      "Browser",
      "Privacy",
      "Password",
      "Copyright",
      "Digital citizenship",
      "Privacy",
      "Security",
      "Copyright",
      "Permission",
      "Cyberbullying",
      "Device care"
    ],
    "classExercises": [
      "Define the internet. Answer: A worldwide network connecting devices to share information and services.",
      "Name two educational uses of the internet. Answer: Research and accessing learning materials.",
      "State two online safety rules. Answer: Keep passwords private and tell a trusted adult about uncomfortable interactions.",
      "State two examples of good digital citizenship. Answer: Be respectful online and protect private information.",
      "What is copyright? Answer: Legal protection for a creator's original work.",
      "Give one way to care for a computer. Answer: Keep liquids away and handle it carefully."
    ],
    "commonMistakes": [
      "Believing every website is accurate.",
      "Sharing private information or passwords with strangers.",
      "Forwarding messages without checking whether they are true.",
      "Sharing another person's information or image without permission."
    ],
    "summary": "The internet provides useful services, but information must be checked and privacy protected. Respectful behaviour matters online. Responsible digital citizenship also means respectful communication, privacy protection and respect for copyright.",
    "examinationPractice": [
      {
        "question": "An application used to visit websites is a _____.",
        "answer": "Web browser",
        "explanation": "Browsers display web pages."
      },
      {
        "question": "Should a learner share a password with an online stranger?",
        "answer": "No",
        "explanation": "Passwords must be kept private."
      },
      {
        "question": "Using technology responsibly and respectfully is called _____.",
        "answer": "Digital citizenship",
        "explanation": "It describes good conduct in digital spaces."
      },
      {
        "question": "Should another person's private photo be shared without permission?",
        "answer": "No",
        "explanation": "Respect privacy and ask permission."
      }
    ]
  },
  {
    "week": 8,
    "title": "Introduction to Word Processing",
    "objectives": [
      "Explain word processing.",
      "Identify common uses of word-processing software.",
      "Recognise basic parts of a word-processing window."
    ],
    "introduction": "Word processing is the use of computer software to create, edit, format, save and print text documents.",
    "sections": [
      {
        "heading": "Uses",
        "content": "A word processor can be used to write letters, class assignments, reports, notices and simple tables."
      },
      {
        "heading": "Common Features",
        "content": "The typing area is where text is entered. The toolbar or ribbon provides commands. The cursor shows where the next character will appear. Menus provide additional options."
      },
      {
        "heading": "Editing and Formatting",
        "content": "Editing changes the content, such as adding or removing words. Formatting changes appearance, such as font style, size, alignment and spacing."
      },
      {
        "heading": "Examples of Applications",
        "content": "Examples include Microsoft Word, LibreOffice Writer and other word-processing applications. Different applications may have different layouts."
      }
    ],
    "workedExamples": [
      {
        "question": "Which type of software is used to prepare a typed letter?",
        "solution": "A word processor."
      },
      {
        "question": "Is changing text from regular to bold editing or formatting?",
        "solution": "Formatting."
      }
    ],
    "keyTerms": [
      "Word processing",
      "Document",
      "Cursor",
      "Toolbar",
      "Ribbon",
      "Editing",
      "Formatting",
      "Alignment"
    ],
    "classExercises": [
      "Define word processing. Answer: Creating, editing, formatting, saving and printing text documents using software.",
      "Name two documents a learner can prepare. Answer: A letter and a class assignment.",
      "What is formatting? Answer: Changing the appearance of text or a document."
    ],
    "commonMistakes": [
      "Confusing editing with formatting.",
      "Assuming every word processor has exactly the same screen layout."
    ],
    "summary": "Word processors help users prepare documents. Editing changes content, while formatting changes appearance.",
    "examinationPractice": [
      {
        "question": "Changing the font size is an example of _____.",
        "answer": "Formatting",
        "explanation": "It changes the appearance of the text."
      },
      {
        "question": "The blinking marker showing where text will appear is the _____.",
        "answer": "Cursor",
        "explanation": "The cursor indicates the insertion point."
      }
    ]
  },
  {
    "week": 9,
    "title": "Creating, Naming and Saving Documents",
    "objectives": [
      "Create a simple document.",
      "Explain why documents should be named and saved.",
      "Identify common save commands."
    ],
    "introduction": "Saving a document stores the work so it can be opened and edited later.",
    "sections": [
      {
        "heading": "Creating a Document",
        "content": "Open a word-processing application and choose a blank document or a suitable template. Type a short heading and paragraph."
      },
      {
        "heading": "Naming a File",
        "content": "Use a short, meaningful file name, such as JSS1_Science_Notes. Avoid confusing names and follow the teacher's file-naming instructions."
      },
      {
        "heading": "Saving",
        "content": "Use the Save command and choose an approved folder or location. The first save may ask for a file name and file type. Save again after making important changes."
      },
      {
        "heading": "Opening and Closing",
        "content": "Use Open to find an existing document. Close the document when finished and follow the correct steps for shutting down or signing out of a shared computer."
      }
    ],
    "workedExamples": [
      {
        "question": "Why should a learner save a document?",
        "solution": "To keep the work so it can be opened later and reduce the risk of losing changes."
      },
      {
        "question": "Give a suitable file name for a class assignment.",
        "solution": "JSS1_English_Assignment is a clear example."
      }
    ],
    "keyTerms": [
      "Document",
      "File name",
      "Save",
      "Save As",
      "Open",
      "Folder",
      "File type"
    ],
    "classExercises": [
      "What does Save do? Answer: It stores the current document.",
      "Give two features of a useful file name. Answer: It is meaningful and easy to recognise.",
      "When should work be saved? Answer: After creating it and again after important changes."
    ],
    "commonMistakes": [
      "Closing an application without saving changes.",
      "Using unclear file names such as 'new1' for every document."
    ],
    "summary": "Create a document, give it a clear name and save it in the correct location. Save again after important edits.",
    "examinationPractice": [
      {
        "question": "Which command stores changes to a document?",
        "answer": "Save",
        "explanation": "Save stores the current version of the document."
      },
      {
        "question": "A clear file name should be _____.",
        "answer": "Meaningful and easy to recognise",
        "explanation": "Good names make files easier to locate."
      }
    ]
  },
  {
    "week": 10,
    "title": "First-Term Digital Technologies Revision",
    "objectives": [
      "Review the term's ICT and digital skills topics.",
      "Classify computer parts and devices.",
      "Recall basic internet safety and document skills."
    ],
    "introduction": "This week reviews the main digital technology topics and prepares learners for assessment.",
    "sections": [
      {
        "heading": "Topics to Revise",
        "content": "Review ICT; computer parts and their functions; input and output devices; keyboard skills; storage; internet safety; word processing; and saving documents."
      },
      {
        "heading": "Practical Review",
        "content": "Identify common computer parts, classify devices and explain how to create and save a simple document. Practise typing a short paragraph where a computer is available and supervised."
      },
      {
        "heading": "Safety Review",
        "content": "Review password privacy, respectful communication, careful device handling and how to respond to uncomfortable online interactions."
      }
    ],
    "workedExamples": [
      {
        "question": "Classify a printer.",
        "solution": "Output device."
      },
      {
        "question": "What is the purpose of a file name?",
        "solution": "It helps identify and find the saved document."
      }
    ],
    "keyTerms": [
      "Revision",
      "Hardware",
      "Software",
      "Input",
      "Output",
      "Storage",
      "Digital citizenship"
    ],
    "classExercises": [
      "Name two input devices and two output devices. Answer: Keyboard and mouse; monitor and printer.",
      "What does ICT stand for? Answer: Information and Communication Technology.",
      "State two internet safety rules. Answer: Keep passwords private and tell a trusted adult about uncomfortable interactions."
    ],
    "commonMistakes": [
      "Memorising device names without knowing their functions.",
      "Confusing Save with Print."
    ],
    "summary": "Review device functions, safe internet habits and the steps for creating and saving documents.",
    "examinationPractice": [
      {
        "question": "Which is an example of software?",
        "answer": "A word-processing application",
        "explanation": "Software is a program or set of instructions."
      },
      {
        "question": "Which command keeps a document for later use?",
        "answer": "Save",
        "explanation": "Saving stores the document."
      }
    ]
  },
  {
    "week": 11,
    "title": "Guided Digital Skills Revision",
    "objectives": [
      "Practise classifying computer devices.",
      "Recall document creation and saving steps.",
      "Apply responsible digital-use rules."
    ],
    "introduction": "Use this week to practise the key skills from the term and correct any misunderstandings.",
    "sections": [
      {
        "heading": "Computer Knowledge",
        "content": "Explain the difference between hardware and software and classify input, output and storage devices."
      },
      {
        "heading": "Document Skills",
        "content": "Describe how to open a word processor, enter text, give a document a clear name and save it."
      },
      {
        "heading": "Responsible Use",
        "content": "Protect passwords, respect privacy, check information before sharing and handle devices carefully."
      }
    ],
    "workedExamples": [
      {
        "question": "A learner types a paragraph and saves it. Name the input device and the command used.",
        "solution": "Keyboard; Save."
      },
      {
        "question": "Give one example of responsible internet use.",
        "solution": "Protect private information and check information before sharing it."
      }
    ],
    "keyTerms": [
      "Revision",
      "Practical skill",
      "Privacy",
      "Storage",
      "Document"
    ],
    "classExercises": [
      "Explain the difference between hardware and software. Answer: Hardware is physical equipment; software is programs and instructions.",
      "Name one input and one output device. Answer: Keyboard (input) and monitor (output).",
      "State two rules for online safety. Answer: Keep passwords private and do not share private details with strangers."
    ],
    "commonMistakes": [
      "Failing to distinguish a device from the program running on it.",
      "Sharing passwords or private information online."
    ],
    "summary": "Digital Technologies combines practical computer knowledge with safe, respectful and responsible use of technology.",
    "examinationPractice": [
      {
        "question": "A monitor is an _____ device.",
        "answer": "Output",
        "explanation": "It displays information from the computer."
      },
      {
        "question": "The programs that tell a computer what to do are called _____.",
        "answer": "Software",
        "explanation": "Software consists of programs and instructions."
      }
    ]
  },
  {
    "week": 12,
    "title": "First-Term Digital Technologies Assessment",
    "objectives": [
      "Demonstrate understanding of ICT concepts.",
      "Apply knowledge of computer devices and digital safety.",
      "Review corrections and identify areas for practice."
    ],
    "introduction": "This assessment checks knowledge of ICT, computer parts, input and output, storage, keyboard use, internet safety and word processing.",
    "sections": [
      {
        "heading": "Assessment Areas",
        "content": "Questions may cover ICT meaning and uses, computer hardware and software, input and output devices, storage, keyboard keys, internet safety, word processing and digital citizenship."
      },
      {
        "heading": "Answering Well",
        "content": "Read each question carefully, use correct terms and give examples when requested. For practical tasks, follow the teacher's instructions."
      },
      {
        "heading": "After the Assessment",
        "content": "Review corrections and practise any skills that need improvement. Continue using devices responsibly."
      }
    ],
    "workedExamples": [
      {
        "question": "A learner uses a keyboard to type a paragraph and saves it. Name the input device and the command used to store the work.",
        "solution": "Keyboard; Save."
      },
      {
        "question": "Give one example of responsible internet use.",
        "solution": "Protecting private information and checking information before sharing it."
      }
    ],
    "keyTerms": [
      "Assessment",
      "Practical skill",
      "Correction",
      "Responsible use"
    ],
    "classExercises": [
      "Explain the difference between hardware and software. Answer: Hardware is the physical equipment; software is the programs and instructions.",
      "Name one input and one output device. Answer: Keyboard (input) and monitor (output).",
      "State two rules for online safety. Answer: Keep passwords private and do not share private details with strangers."
    ],
    "commonMistakes": [
      "Failing to distinguish a device from the program running on it.",
      "Sharing passwords or private information online."
    ],
    "summary": "Digital Technologies combines practical computer knowledge with safe, respectful and responsible use of technology.",
    "examinationPractice": [
      {
        "question": "A monitor is an _____ device.",
        "answer": "Output",
        "explanation": "It displays information from the computer."
      },
      {
        "question": "The programs that tell a computer what to do are called _____.",
        "answer": "Software",
        "explanation": "Software consists of programs and instructions."
      }
    ]
  }
];
})();
