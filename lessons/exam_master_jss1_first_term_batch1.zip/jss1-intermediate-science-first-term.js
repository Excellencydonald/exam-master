(function () {
  "use strict";
  window.EXAM_MASTER_LESSONS = window.EXAM_MASTER_LESSONS || {};
  window.EXAM_MASTER_LESSONS["JSS 1"] = window.EXAM_MASTER_LESSONS["JSS 1"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] =
    window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"]["Intermediate Science"] = [
  {
    "week": 1,
    "title": "Introduction to Science and Its Importance",
    "objectives": [
      "Define science in simple terms.",
      "Identify major branches of science.",
      "Explain how science helps people and communities."
    ],
    "introduction": "Science is the careful study of the natural world through observation, questions, investigation and evidence.",
    "sections": [
      {
        "heading": "Meaning of Science",
        "content": "Science is an organised way of learning about living things, materials, energy, the Earth and the universe. Scientists observe, ask questions, suggest explanations and test ideas fairly."
      },
      {
        "heading": "Branches of Science",
        "content": "Biology studies living things; Chemistry studies substances and how they change; Physics studies matter, energy, forces and motion. Environmental science examines relationships between people and their surroundings."
      },
      {
        "heading": "Importance of Science",
        "content": "Science supports healthcare, farming, communication, transport, construction, clean water and environmental protection. In Nigeria, scientific knowledge can help improve crop production and public health."
      },
      {
        "heading": "Scientific Attitudes",
        "content": "A good learner is curious, honest, careful, patient and willing to change an idea when reliable evidence disagrees."
      }
    ],
    "workedExamples": [
      {
        "question": "Which branch studies living organisms?",
        "solution": "Biology studies living organisms."
      },
      {
        "question": "Give two ways science helps a community.",
        "solution": "It supports healthcare and improves farming, among many other uses."
      }
    ],
    "keyTerms": [
      "Science",
      "Observation",
      "Investigation",
      "Biology",
      "Chemistry",
      "Physics",
      "Evidence"
    ],
    "classExercises": [
      "Define science. Answer: The organised study of the natural world using observation and evidence.",
      "Name the three major branches introduced. Answer: Biology, Chemistry and Physics.",
      "State three benefits of science. Answer: Better healthcare, improved farming and safer technology."
    ],
    "commonMistakes": [
      "Thinking that science is only about laboratory work; science also involves everyday observation and problem-solving.",
      "Accepting a claim without checking evidence."
    ],
    "summary": "Science uses observation and evidence to explain the world. Its branches and applications improve daily life.",
    "examinationPractice": [
      {
        "question": "The study of living things is called _____.",
        "answer": "Biology",
        "explanation": "Biology focuses on organisms."
      },
      {
        "question": "Mention one scientific attitude.",
        "answer": "Honesty / curiosity / careful observation",
        "explanation": "Scientific work depends on reliable and fair investigation."
      }
    ]
  },
  {
    "week": 2,
    "title": "Measurement: Length, Mass and Volume",
    "objectives": [
      "Explain why measurement is important.",
      "Name common units for length, mass and volume.",
      "Choose suitable measuring instruments."
    ],
    "introduction": "Measurement tells us how much of a quantity is present. It helps people compare objects and communicate results accurately.",
    "sections": [
      {
        "heading": "Length",
        "content": "Length is the distance from one point to another. Common metric units include millimetre (mm), centimetre (cm), metre (m) and kilometre (km). A ruler or metre rule can measure short lengths."
      },
      {
        "heading": "Mass",
        "content": "Mass is the amount of matter in an object. It is commonly measured in grams (g) and kilograms (kg) using a balance or weighing scale."
      },
      {
        "heading": "Volume",
        "content": "Volume is the space occupied by an object or substance. Liquids are commonly measured in millilitres (mL) and litres (L), using a measuring cylinder or marked container."
      },
      {
        "heading": "Good Measurement",
        "content": "Choose an appropriate instrument, place it correctly, read the scale at eye level and record the number with its unit. Avoid guessing when an instrument is available."
      }
    ],
    "workedExamples": [
      {
        "question": "Convert 2 metres to centimetres.",
        "solution": "1 metre = 100 centimetres, so 2 m = 200 cm."
      },
      {
        "question": "Which instrument is suitable for measuring 50 mL of water?",
        "solution": "A measuring cylinder or suitable graduated measuring container."
      }
    ],
    "keyTerms": [
      "Measurement",
      "Length",
      "Mass",
      "Volume",
      "Metre",
      "Kilogram",
      "Litre",
      "Measuring cylinder"
    ],
    "classExercises": [
      "State the SI unit commonly used for length. Answer: metre (m).",
      "Convert 3 kg to grams. Answer: 3,000 g.",
      "Name an instrument for measuring liquid volume. Answer: Measuring cylinder."
    ],
    "commonMistakes": [
      "Writing a measurement without a unit.",
      "Confusing mass with volume.",
      "Reading a scale from an angle instead of eye level."
    ],
    "summary": "Accurate measurement requires the correct instrument, suitable unit and careful reading.",
    "examinationPractice": [
      {
        "question": "The amount of matter in an object is its _____.",
        "answer": "Mass",
        "explanation": "Mass describes the amount of matter."
      },
      {
        "question": "How many centimetres are in one metre?",
        "answer": "100 cm",
        "explanation": "One metre equals one hundred centimetres."
      }
    ]
  },
  {
    "week": 3,
    "title": "Matter and Its States",
    "objectives": [
      "Define matter.",
      "Identify the three common states of matter.",
      "Compare the properties of solids, liquids and gases."
    ],
    "introduction": "Matter is anything that has mass and occupies space. Most materials around us are solids, liquids or gases.",
    "sections": [
      {
        "heading": "Solids",
        "content": "A solid has a fairly fixed shape and volume. Its particles are close together and vibrate around fixed positions. Examples include a stone, book and ice."
      },
      {
        "heading": "Liquids",
        "content": "A liquid has a fixed volume but takes the shape of its container. Its particles can move past one another. Examples include water, palm oil and milk."
      },
      {
        "heading": "Gases",
        "content": "A gas has no fixed shape or volume. It spreads to fill the available space. Examples include air and water vapour."
      },
      {
        "heading": "Changes of State",
        "content": "Melting changes a solid to a liquid; freezing changes a liquid to a solid; evaporation changes a liquid to gas; condensation changes gas to liquid. Heating or cooling causes these changes."
      }
    ],
    "workedExamples": [
      {
        "question": "What happens when ice is heated until it melts?",
        "solution": "It changes from a solid to liquid water."
      },
      {
        "question": "Which state of matter spreads to fill a container?",
        "solution": "A gas."
      }
    ],
    "keyTerms": [
      "Matter",
      "Solid",
      "Liquid",
      "Gas",
      "Melting",
      "Freezing",
      "Evaporation",
      "Condensation"
    ],
    "classExercises": [
      "Give two examples of solids. Answer: Stone and book.",
      "State one property of a liquid. Answer: It has a fixed volume but takes the shape of its container.",
      "What is condensation? Answer: The change of a gas or vapour into a liquid."
    ],
    "commonMistakes": [
      "Saying that air is not matter; air has mass and occupies space.",
      "Thinking that a liquid has a fixed shape."
    ],
    "summary": "Matter has mass and occupies space. Solids, liquids and gases have different particle arrangements and properties.",
    "examinationPractice": [
      {
        "question": "Which state has a fixed volume but no fixed shape?",
        "answer": "Liquid",
        "explanation": "A liquid keeps its volume but takes the container's shape."
      },
      {
        "question": "The change from liquid to solid is called _____.",
        "answer": "Freezing",
        "explanation": "Cooling can cause a liquid to freeze."
      }
    ]
  },
  {
    "week": 4,
    "title": "Living and Non-living Things",
    "objectives": [
      "Distinguish living things from non-living things.",
      "List characteristics of living things.",
      "Classify familiar examples."
    ],
    "introduction": "Living things carry out life processes. Non-living things do not carry out these processes by themselves.",
    "sections": [
      {
        "heading": "Characteristics of Living Things",
        "content": "Living things generally move, respire, respond to changes, grow, reproduce, remove waste and obtain nutrients. These are often remembered as MRS GREN."
      },
      {
        "heading": "Examples",
        "content": "Humans, goats, maize plants, insects and bacteria are living things. A stone, chair, pencil and cup are non-living things."
      },
      {
        "heading": "Plants and Animals",
        "content": "Animals usually move from place to place and obtain food by eating. Plants usually make food using sunlight, water and carbon dioxide, and respond to their environment."
      },
      {
        "heading": "Things That Were Once Alive",
        "content": "Wood and paper come from plants, but a wooden desk or sheet of paper is no longer living because it does not carry out life processes."
      }
    ],
    "workedExamples": [
      {
        "question": "Is a growing maize plant living? Give a reason.",
        "solution": "Yes. It grows and carries out other life processes."
      },
      {
        "question": "Is a wooden chair living?",
        "solution": "No. It came from a living tree, but it no longer carries out life processes."
      }
    ],
    "keyTerms": [
      "Living thing",
      "Non-living thing",
      "Growth",
      "Respiration",
      "Reproduction",
      "Nutrition",
      "Excretion",
      "Sensitivity"
    ],
    "classExercises": [
      "List four characteristics of living things. Answer: Any four of movement, respiration, sensitivity, growth, reproduction, excretion and nutrition.",
      "Classify a goat. Answer: Living thing.",
      "Why is a wooden table non-living? Answer: It does not carry out life processes."
    ],
    "commonMistakes": [
      "Assuming that movement alone proves something is alive; wind moves but is not living.",
      "Calling wood living simply because it came from a tree."
    ],
    "summary": "Living things carry out life processes. Non-living things do not, even if they can move when pushed or blown.",
    "examinationPractice": [
      {
        "question": "Which is a life process?",
        "answer": "Respiration",
        "explanation": "Living organisms release energy from food through respiration."
      },
      {
        "question": "A wooden ruler is classified as _____.",
        "answer": "Non-living",
        "explanation": "It does not perform life processes."
      }
    ]
  },
  {
    "week": 5,
    "title": "The Human Body: Organs and Systems",
    "objectives": [
      "Identify selected human body organs.",
      "Describe simple functions of major organs.",
      "Explain why body systems work together."
    ],
    "introduction": "The human body is made of organs that perform special functions. Organs work together in systems to keep the body alive and healthy.",
    "sections": [
      {
        "heading": "Organs",
        "content": "The heart pumps blood; the lungs help the body take in oxygen and remove carbon dioxide; the brain coordinates many body activities; the stomach helps digest food; the kidneys help remove wastes from the blood."
      },
      {
        "heading": "Body Systems",
        "content": "The circulatory system moves blood around the body. The respiratory system supports breathing. The digestive system breaks food into substances the body can use. The nervous system receives information and coordinates responses."
      },
      {
        "heading": "Working Together",
        "content": "During exercise, muscles need more oxygen and nutrients. The respiratory and circulatory systems work together to supply them."
      },
      {
        "heading": "Healthy Habits",
        "content": "Balanced meals, safe water, physical activity, rest and good hygiene support the body. Persistent pain or illness should be discussed with a trusted adult and a health professional."
      }
    ],
    "workedExamples": [
      {
        "question": "Which organ pumps blood?",
        "solution": "The heart."
      },
      {
        "question": "Which system is mainly responsible for digestion?",
        "solution": "The digestive system."
      }
    ],
    "keyTerms": [
      "Organ",
      "Organ system",
      "Heart",
      "Lungs",
      "Brain",
      "Kidneys",
      "Circulatory system",
      "Respiratory system"
    ],
    "classExercises": [
      "Name the organ that coordinates many body activities. Answer: Brain.",
      "State one function of the lungs. Answer: They help take in oxygen and remove carbon dioxide.",
      "Why do body systems work together? Answer: To perform the activities needed to keep the body alive and functioning."
    ],
    "commonMistakes": [
      "Saying that the stomach pumps blood; the heart pumps blood.",
      "Thinking that organs work completely independently."
    ],
    "summary": "Organs have specialised functions, and organ systems work together to maintain life and health.",
    "examinationPractice": [
      {
        "question": "The heart belongs to which system?",
        "answer": "Circulatory system",
        "explanation": "It pumps blood around the body."
      },
      {
        "question": "Which organ helps coordinate body activities?",
        "answer": "Brain",
        "explanation": "The brain is a major control centre of the nervous system."
      }
    ]
  },
  {
    "week": 6,
    "title": "Energy: Forms and Uses",
    "objectives": [
      "Explain energy in simple terms.",
      "Identify common forms of energy.",
      "Give examples of energy changes."
    ],
    "introduction": "Energy is the ability to cause change or do work. We use energy at home, in school, on farms and in transport.",
    "sections": [
      {
        "heading": "Forms of Energy",
        "content": "Common forms include heat (thermal), light, sound, electrical, chemical and movement (kinetic) energy. Stored energy due to position is called potential energy."
      },
      {
        "heading": "Sources of Energy",
        "content": "The Sun is a major natural source. Other sources include food, fuels, batteries, moving water and wind. Some sources are renewable, while others are non-renewable."
      },
      {
        "heading": "Energy Changes",
        "content": "An electric bulb changes electrical energy mainly into light and heat. A battery stores chemical energy and supplies electrical energy in a circuit. Food provides chemical energy for the body."
      },
      {
        "heading": "Safe and Responsible Use",
        "content": "Use electrical appliances carefully, keep water away from electrical equipment and follow adult instructions. Save energy by switching off lights and appliances when they are not needed."
      }
    ],
    "workedExamples": [
      {
        "question": "What energy change occurs in a lit electric bulb?",
        "solution": "Electrical energy changes mainly into light and heat energy."
      },
      {
        "question": "What is the main source of energy for most life on Earth?",
        "solution": "The Sun."
      }
    ],
    "keyTerms": [
      "Energy",
      "Thermal energy",
      "Light energy",
      "Sound energy",
      "Electrical energy",
      "Chemical energy",
      "Renewable",
      "Non-renewable"
    ],
    "classExercises": [
      "Name three forms of energy. Answer: Any three of heat, light, sound, electrical, chemical or kinetic energy.",
      "What type of energy is stored in food? Answer: Chemical energy.",
      "Give one way to save electricity. Answer: Switch off unused lights and appliances."
    ],
    "commonMistakes": [
      "Saying energy is destroyed in every change; energy is transferred or transformed.",
      "Touching electrical equipment with wet hands."
    ],
    "summary": "Energy exists in different forms and changes from one form to another. Safe use and conservation are important.",
    "examinationPractice": [
      {
        "question": "A battery stores mainly _____ energy.",
        "answer": "Chemical",
        "explanation": "Chemical energy is converted to electrical energy when the battery is used."
      },
      {
        "question": "The Sun provides Earth with light and _____.",
        "answer": "Heat",
        "explanation": "Solar energy reaches Earth as light and thermal energy."
      }
    ]
  },
  {
    "week": 7,
    "title": "Force and Motion",
    "objectives": [
      "Define force and motion.",
      "Identify pushes and pulls as forces.",
      "Describe simple effects of force."
    ],
    "introduction": "A force is a push or pull. Motion occurs when an object's position changes over time.",
    "sections": [
      {
        "heading": "Types of Force",
        "content": "A push moves an object away; a pull brings it closer. Examples include pushing a door and pulling a drawer."
      },
      {
        "heading": "Effects of Force",
        "content": "A force can start or stop motion, change speed, change direction or change shape. The effect depends on the size and direction of the force."
      },
      {
        "heading": "Friction and Gravity",
        "content": "Friction is a force that opposes movement between surfaces in contact. Gravity is the force that attracts objects towards one another; on Earth it pulls objects towards the ground."
      },
      {
        "heading": "Describing Motion",
        "content": "We can describe motion by comparing an object's position with a reference point. A moving bus changes position relative to a roadside tree."
      }
    ],
    "workedExamples": [
      {
        "question": "Give one example of a pull.",
        "solution": "Pulling a school bag by its handle."
      },
      {
        "question": "Why does a rolling ball eventually slow down on the ground?",
        "solution": "Friction between the ball and the ground, together with air resistance, opposes its motion."
      }
    ],
    "keyTerms": [
      "Force",
      "Push",
      "Pull",
      "Motion",
      "Friction",
      "Gravity",
      "Reference point"
    ],
    "classExercises": [
      "Define force. Answer: A push or pull.",
      "State two effects of force. Answer: It can change speed and direction; it can also start, stop or change shape.",
      "Name the force that pulls objects towards Earth. Answer: Gravity."
    ],
    "commonMistakes": [
      "Thinking that force is needed only to start motion; forces can also slow or change moving objects.",
      "Confusing friction with gravity."
    ],
    "summary": "A force is a push or pull and can change an object's motion or shape. Friction opposes motion, while gravity attracts objects.",
    "examinationPractice": [
      {
        "question": "A force is a _____.",
        "answer": "Push or pull",
        "explanation": "This is the basic definition of force."
      },
      {
        "question": "The force that opposes motion between touching surfaces is _____.",
        "answer": "Friction",
        "explanation": "Friction acts between surfaces in contact."
      }
    ]
  },
  {
    "week": 8,
    "title": "Soil: Formation, Types and Uses",
    "objectives": [
      "Explain what soil is.",
      "Identify common soil types.",
      "Describe uses and ways to care for soil."
    ],
    "introduction": "Soil is the upper layer of the Earth's surface in which many plants grow. It contains mineral particles, organic matter, air and water.",
    "sections": [
      {
        "heading": "Soil Formation",
        "content": "Soil forms slowly as rocks break down through weathering and organic materials decay. Water, wind, temperature changes and living organisms contribute to the process."
      },
      {
        "heading": "Types of Soil",
        "content": "Sandy soil has relatively large particles and drains quickly. Clayey soil has very small particles and holds more water. Loamy soil is a mixture of sand, silt, clay and organic matter and is often suitable for many crops."
      },
      {
        "heading": "Importance of Soil",
        "content": "Soil supports plant growth, provides a home for many organisms, stores water and supplies materials for construction."
      },
      {
        "heading": "Soil Conservation",
        "content": "Plant cover, careful farming, mulching and planting trees can reduce erosion. Avoid dumping harmful waste on land."
      }
    ],
    "workedExamples": [
      {
        "question": "Which soil type usually drains water quickly?",
        "solution": "Sandy soil."
      },
      {
        "question": "Why is loamy soil useful for many crops?",
        "solution": "It contains a balanced mixture of particles and organic matter and can hold both air and water."
      }
    ],
    "keyTerms": [
      "Soil",
      "Weathering",
      "Humus",
      "Sandy soil",
      "Clayey soil",
      "Loamy soil",
      "Erosion",
      "Conservation"
    ],
    "classExercises": [
      "Name three common soil types. Answer: Sandy, clayey and loamy soil.",
      "What is humus? Answer: Decayed organic matter in soil.",
      "State one way to reduce soil erosion. Answer: Maintain plant cover or plant trees."
    ],
    "commonMistakes": [
      "Assuming all soil types hold the same amount of water.",
      "Removing vegetation carelessly, which can increase erosion."
    ],
    "summary": "Soil forms over time and supports life and farming. Soil conservation helps protect this valuable resource.",
    "examinationPractice": [
      {
        "question": "Which soil type has very small particles and holds much water?",
        "answer": "Clayey soil",
        "explanation": "Clay particles are very small and hold water."
      },
      {
        "question": "The removal of topsoil by water or wind is called _____.",
        "answer": "Soil erosion",
        "explanation": "Erosion carries soil away."
      }
    ]
  },
  {
    "week": 9,
    "title": "Simple Machines",
    "objectives": [
      "Explain what a simple machine is.",
      "Identify common simple machines.",
      "Give examples of their uses."
    ],
    "introduction": "Simple machines make work easier by changing the size or direction of a force. They do not remove the need to do work.",
    "sections": [
      {
        "heading": "Types of Simple Machines",
        "content": "Common types are lever, pulley, wheel and axle, inclined plane, wedge and screw."
      },
      {
        "heading": "Examples",
        "content": "A seesaw and crowbar are levers. A ramp is an inclined plane. A knife is a wedge. A jar lid uses a screw-like thread. A wheelbarrow combines a lever with a wheel and axle."
      },
      {
        "heading": "How They Help",
        "content": "A ramp allows a load to be moved to a higher place with less force over a longer distance. A pulley can change the direction of a pull."
      },
      {
        "heading": "Care and Safety",
        "content": "Use tools for their intended purpose, keep sharp tools handled by responsible adults and store equipment safely."
      }
    ],
    "workedExamples": [
      {
        "question": "What type of simple machine is a ramp?",
        "solution": "An inclined plane."
      },
      {
        "question": "Give one example of a lever.",
        "solution": "A seesaw, crowbar or bottle opener."
      }
    ],
    "keyTerms": [
      "Simple machine",
      "Lever",
      "Pulley",
      "Wheel and axle",
      "Inclined plane",
      "Wedge",
      "Screw"
    ],
    "classExercises": [
      "List four types of simple machines. Answer: Any four of lever, pulley, wheel and axle, inclined plane, wedge and screw.",
      "Classify a seesaw. Answer: Lever.",
      "State one use of a pulley. Answer: It can change the direction of a pulling force."
    ],
    "commonMistakes": [
      "Calling every machine a simple machine; many machines combine several simple machines.",
      "Using tools carelessly or for the wrong purpose."
    ],
    "summary": "Simple machines change how forces are applied and can make tasks easier. Examples are found in homes, schools and workplaces.",
    "examinationPractice": [
      {
        "question": "A ramp is an example of a/an _____.",
        "answer": "Inclined plane",
        "explanation": "A ramp is a sloping surface."
      },
      {
        "question": "A seesaw is an example of a _____.",
        "answer": "Lever",
        "explanation": "A lever turns around a fixed point called a fulcrum."
      }
    ]
  },
  {
    "week": 10,
    "title": "First-Term Revision and Tests",
    "objectives": [
      "Review the main science topics covered during the term.",
      "Answer mixed questions using scientific vocabulary.",
      "Identify topics that need more practice."
    ],
    "introduction": "This week reviews the term's science topics and gives learners practice answering questions.",
    "sections": [
      {
        "heading": "Topics to Revise",
        "content": "Revise science and its branches; measurement; matter; living and non-living things; human body organs and systems; energy; force and motion; soil; and simple machines."
      },
      {
        "heading": "How to Revise",
        "content": "Read each topic, explain key ideas in your own words, practise worked examples and check answers."
      },
      {
        "heading": "Safe Science Practice",
        "content": "Follow teacher instructions, use equipment only with permission and never taste unknown substances."
      }
    ],
    "workedExamples": [
      {
        "question": "Which instrument can measure the volume of a liquid?",
        "solution": "A measuring cylinder."
      },
      {
        "question": "What type of simple machine is a ramp?",
        "solution": "An inclined plane."
      }
    ],
    "keyTerms": [
      "Revision",
      "Scientific vocabulary",
      "Measurement",
      "Classification"
    ],
    "classExercises": [
      "Name the three common states of matter. Answer: Solid, liquid and gas.",
      "Which organ pumps blood? Answer: The heart.",
      "Name one way to reduce soil erosion. Answer: Plant trees or maintain ground cover."
    ],
    "commonMistakes": [
      "Memorising words without understanding their meanings.",
      "Leaving out units when recording measurements."
    ],
    "summary": "Review every topic, practise explaining answers and correct misunderstandings before the assessment.",
    "examinationPractice": [
      {
        "question": "What is the SI unit of length?",
        "answer": "Metre",
        "explanation": "The metre is the standard SI unit for length."
      },
      {
        "question": "What is the change from liquid to gas called?",
        "answer": "Evaporation",
        "explanation": "Evaporation changes a liquid into a gas at its surface."
      }
    ]
  },
  {
    "week": 11,
    "title": "Guided Revision and Science Practice",
    "objectives": [
      "Recall the main ideas from Weeks 1–10.",
      "Answer mixed questions using scientific vocabulary.",
      "Identify topics that need more practice."
    ],
    "introduction": "Use this week to practise explaining science ideas, interpreting simple observations and correcting mistakes from earlier lessons.",
    "sections": [
      {
        "heading": "Revision Checklist",
        "content": "Check that you can define science, choose measuring instruments, compare states of matter, identify life processes, name organ functions and explain energy, force, soil and simple machines."
      },
      {
        "heading": "Practice Strategy",
        "content": "Attempt questions without looking at the answers first. Then check your work and rewrite any incorrect explanation."
      },
      {
        "heading": "Classroom Practice",
        "content": "With teacher guidance, practise measuring safe everyday objects, classifying materials and identifying simple machines around the school."
      }
    ],
    "workedExamples": [
      {
        "question": "A liquid changes into gas at its surface. Name the process.",
        "solution": "Evaporation."
      },
      {
        "question": "A student uses a ruler to measure a book. Which quantity is measured?",
        "solution": "Length."
      }
    ],
    "keyTerms": [
      "Revision",
      "Scientific vocabulary",
      "Classification",
      "Measurement"
    ],
    "classExercises": [
      "Explain the difference between mass and volume. Answer: Mass is the amount of matter; volume is the space occupied.",
      "State two effects of force. Answer: A force can start, stop, speed up, slow down, change direction or change shape.",
      "Name two ways to protect soil. Answer: Plant vegetation and use suitable soil-conservation practices."
    ],
    "commonMistakes": [
      "Memorising words without understanding their meaning.",
      "Skipping questions that seem difficult instead of practising them."
    ],
    "summary": "Review every topic, practise explaining answers and correct misunderstandings before the assessment.",
    "examinationPractice": [
      {
        "question": "Which force attracts objects towards Earth?",
        "answer": "Gravity",
        "explanation": "Gravity attracts objects towards one another."
      },
      {
        "question": "Which state of matter has no fixed shape or volume?",
        "answer": "Gas",
        "explanation": "A gas spreads to fill the available space."
      }
    ]
  },
  {
    "week": 12,
    "title": "First-Term Science Assessment",
    "objectives": [
      "Demonstrate understanding of the term's topics.",
      "Apply scientific ideas to simple situations.",
      "Review answers and learn from mistakes."
    ],
    "introduction": "This assessment checks understanding of the topics covered during the term. Read each question carefully and show working where needed.",
    "sections": [
      {
        "heading": "Assessment Areas",
        "content": "Questions may cover branches of science, measurement and units, states of matter, life processes, body organs, energy, forces, soil and simple machines."
      },
      {
        "heading": "How to Answer",
        "content": "Read the instruction, identify what is being asked, use correct scientific terms and give examples where requested."
      },
      {
        "heading": "After the Assessment",
        "content": "Check corrections, revisit difficult topics and ask the teacher to explain any answer you do not understand."
      }
    ],
    "workedExamples": [
      {
        "question": "A learner measures 250 mL of water. What is being measured?",
        "solution": "The volume of the water."
      },
      {
        "question": "A bicycle uses wheels and axles. Name another simple machine.",
        "solution": "Any correct example, such as a lever, pulley, wedge, screw or inclined plane."
      }
    ],
    "keyTerms": [
      "Assessment",
      "Evidence",
      "Correction",
      "Scientific explanation"
    ],
    "classExercises": [
      "Explain the difference between mass and volume. Answer: Mass is the amount of matter; volume is the space occupied.",
      "State two effects of force. Answer: A force can start, stop, speed up, slow down, change direction or change shape.",
      "Name two ways to protect soil. Answer: Plant vegetation and use suitable soil-conservation practices."
    ],
    "commonMistakes": [
      "Rushing and failing to read the full question.",
      "Giving an example without explaining it when an explanation is requested."
    ],
    "summary": "An assessment measures understanding and also shows which topics need more practice.",
    "examinationPractice": [
      {
        "question": "What is the SI unit of length?",
        "answer": "Metre",
        "explanation": "The metre is the standard SI unit for length."
      },
      {
        "question": "Name the force that attracts objects towards Earth.",
        "answer": "Gravity",
        "explanation": "Gravity pulls objects towards Earth's centre."
      }
    ]
  }
];
})();
