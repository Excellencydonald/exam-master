(function () {
  "use strict";
  window.EXAM_MASTER_LESSONS = window.EXAM_MASTER_LESSONS || {};
  window.EXAM_MASTER_LESSONS["JSS 1"] = window.EXAM_MASTER_LESSONS["JSS 1"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] =
    window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"] || {};
  window.EXAM_MASTER_LESSONS["JSS 1"]["First Term"]["Physical and Health Education"] = [
  {
    "week": 1,
    "title": "Importance of Physical Fitness",
    "objectives": [
      "Define Physical and Health Education.",
      "Explain the importance of physical activity.",
      "Identify healthy habits for learners.",
      "Explain physical fitness.",
      "Identify basic components of fitness.",
      "Give examples of activities that develop fitness."
    ],
    "introduction": "Physical and Health Education teaches learners how to care for their bodies, stay active, work with others and make healthy choices.",
    "sections": [
      {
        "heading": "Meaning of PHE",
        "content": "Physical Education involves planned movement, games, sports and fitness activities. Health Education teaches knowledge and habits that support physical, mental and social well-being."
      },
      {
        "heading": "Importance",
        "content": "Regular suitable activity supports strong bones and muscles, heart and lung fitness, coordination, confidence and teamwork. Health knowledge helps people prevent illness and make informed choices."
      },
      {
        "heading": "Areas of Health",
        "content": "Physical health concerns the body; mental and emotional health concern thoughts and feelings; social health concerns relationships and respectful interaction."
      },
      {
        "heading": "Balanced Living",
        "content": "Healthy living includes suitable activity, nutritious food, clean water, rest, personal hygiene and supportive relationships."
      },
      {
        "heading": "Components of Fitness",
        "content": "Endurance helps the body continue activity; strength is the ability of muscles to exert force; flexibility is the ability of joints to move through a range; speed is moving quickly; coordination is using body parts together smoothly; balance is maintaining stability."
      },
      {
        "heading": "Fitness Activities",
        "content": "Walking, dancing, swimming in a supervised safe setting, and age-appropriate games can support endurance. Gentle stretching supports flexibility. Body-weight movements under teacher guidance can develop strength."
      },
      {
        "heading": "Personal Differences",
        "content": "Fitness levels differ. Learners should work at a comfortable level, build skills gradually and follow teacher guidance rather than compete to push beyond safe limits."
      },
      {
        "heading": "Warm-up and Cool-down",
        "content": "A warm-up prepares the body for activity. A cool-down allows activity to end gradually. Both should be guided by the teacher and suited to the activity."
      }
    ],
    "workedExamples": [
      {
        "question": "Give two benefits of physical activity.",
        "solution": "It supports fitness and helps develop coordination."
      },
      {
        "question": "What does Health Education teach?",
        "solution": "It teaches knowledge and habits that support well-being and healthy choices."
      },
      {
        "question": "Which fitness component helps a person bend and reach comfortably?",
        "solution": "Flexibility."
      },
      {
        "question": "Which component helps a learner maintain a steady position?",
        "solution": "Balance."
      }
    ],
    "keyTerms": [
      "Physical Education",
      "Health Education",
      "Fitness",
      "Well-being",
      "Coordination",
      "Teamwork",
      "Physical fitness",
      "Endurance",
      "Strength",
      "Flexibility",
      "Speed",
      "Coordination",
      "Balance",
      "Warm-up",
      "Cool-down"
    ],
    "classExercises": [
      "Define Physical Education. Answer: Planned physical activities, movement, games and sports that develop fitness and skills.",
      "State three benefits of regular physical activity. Answer: Fitness, stronger muscles and bones, and improved coordination.",
      "Name two parts of healthy living besides exercise. Answer: Nutritious food and adequate rest.",
      "Name four components of fitness. Answer: Any four of endurance, strength, flexibility, speed, coordination and balance.",
      "What is a warm-up? Answer: Gentle activity that prepares the body for exercise.",
      "Why should learners build activity gradually? Answer: To allow the body to adapt and reduce the chance of injury."
    ],
    "commonMistakes": [
      "Thinking PHE is only competitive sports; it also includes health knowledge and everyday movement.",
      "Believing that one activity suits every person's ability.",
      "Confusing flexibility with strength.",
      "Starting vigorous activity without an appropriate warm-up."
    ],
    "summary": "PHE develops movement skills and teaches healthy habits. Activity should be suitable, safe and enjoyable. Fitness includes endurance, strength, flexibility, speed, coordination and balance.",
    "examinationPractice": [
      {
        "question": "PHE stands for _____.",
        "answer": "Physical and Health Education",
        "explanation": "It combines physical activity learning and health education."
      },
      {
        "question": "State one benefit of teamwork in games.",
        "answer": "It encourages cooperation and communication",
        "explanation": "Team activities help learners work together respectfully."
      },
      {
        "question": "The ability of a muscle to exert force is called _____.",
        "answer": "Strength",
        "explanation": "Strength concerns the force muscles can produce."
      },
      {
        "question": "The ability to move joints through a range is _____.",
        "answer": "Flexibility",
        "explanation": "Flexibility supports comfortable movement."
      }
    ]
  },
  {
    "week": 2,
    "title": "Types of Exercise and Safe Participation",
    "objectives": [
      "Identify common types of exercise.",
      "Explain the purpose of different exercises.",
      "Follow basic safety rules during activity."
    ],
    "introduction": "Exercise is planned physical activity that helps develop or maintain fitness and movement skills.",
    "sections": [
      {
        "heading": "Aerobic Activities",
        "content": "Activities such as brisk walking, dancing and suitable games involve repeated movement and make the heart and lungs work harder."
      },
      {
        "heading": "Strength and Flexibility Activities",
        "content": "Age-appropriate body-weight activities can help develop strength. Gentle stretching can help maintain flexibility. Exercises should be demonstrated and supervised by the teacher."
      },
      {
        "heading": "Skill and Balance Activities",
        "content": "Throwing and catching soft balls, simple movement patterns and balance games develop coordination and control."
      },
      {
        "heading": "Safe Participation",
        "content": "Wear suitable clothing and footwear, use safe spaces and equipment, drink water when appropriate, obey instructions and stop to tell the teacher if unwell or uncomfortable."
      }
    ],
    "workedExamples": [
      {
        "question": "Give one example of an aerobic activity.",
        "solution": "Brisk walking or dancing."
      },
      {
        "question": "Which type of activity helps maintain flexibility?",
        "solution": "Gentle stretching."
      }
    ],
    "keyTerms": [
      "Exercise",
      "Aerobic activity",
      "Strength",
      "Stretching",
      "Coordination",
      "Safety"
    ],
    "classExercises": [
      "Name two aerobic activities. Answer: Brisk walking and dancing.",
      "State two exercise safety rules. Answer: Use suitable footwear and follow teacher instructions.",
      "Why should equipment be checked? Answer: To make sure it is suitable and safe to use."
    ],
    "commonMistakes": [
      "Copying advanced exercises without instruction.",
      "Ignoring discomfort or continuing when feeling unwell."
    ],
    "summary": "Different exercises develop different skills. Choose suitable activities and follow safety instructions.",
    "examinationPractice": [
      {
        "question": "Which activity mainly supports flexibility?",
        "answer": "Gentle stretching",
        "explanation": "Stretching helps joints move through a comfortable range."
      },
      {
        "question": "What should a learner do when feeling unwell during exercise?",
        "answer": "Stop and tell the teacher",
        "explanation": "An adult can help decide what action is needed."
      }
    ]
  },
  {
    "week": 3,
    "title": "Personal Hygiene and Environmental Sanitation",
    "objectives": [
      "Explain personal hygiene and sanitation.",
      "Identify daily hygiene practices.",
      "Describe ways to keep the school environment clean."
    ],
    "introduction": "Personal hygiene means caring for the body. Environmental sanitation means keeping our surroundings clean and safe.",
    "sections": [
      {
        "heading": "Personal Hygiene",
        "content": "Important habits include bathing, washing hands with soap and clean water, brushing teeth, wearing clean clothes, keeping nails clean and using a clean toilet."
      },
      {
        "heading": "Handwashing",
        "content": "Wash hands with soap and clean water after using the toilet, before eating or preparing food, and after handling rubbish or animals. Clean all parts of the hands and rinse well."
      },
      {
        "heading": "Environmental Sanitation",
        "content": "Put waste in appropriate bins, keep drains clear through approved community services, protect drinking water and avoid littering."
      },
      {
        "heading": "Shared Responsibility",
        "content": "Learners, families, schools and communities all help maintain clean surroundings. Report unsafe or dirty areas to a responsible adult."
      }
    ],
    "workedExamples": [
      {
        "question": "When should hands be washed before a meal?",
        "solution": "Before eating, using soap and clean water."
      },
      {
        "question": "Give one example of environmental sanitation.",
        "solution": "Putting rubbish in a proper bin and keeping the school compound clean."
      }
    ],
    "keyTerms": [
      "Personal hygiene",
      "Sanitation",
      "Handwashing",
      "Waste",
      "Clean water",
      "Littering"
    ],
    "classExercises": [
      "State four personal hygiene habits. Answer: Bathing, brushing teeth, handwashing and wearing clean clothes.",
      "Give two times when handwashing is important. Answer: After using the toilet and before eating.",
      "What is sanitation? Answer: Keeping the environment clean and safe."
    ],
    "commonMistakes": [
      "Washing hands with water only when soap is available.",
      "Throwing rubbish into drains or open spaces."
    ],
    "summary": "Personal hygiene protects individual health, while sanitation helps protect the whole community.",
    "examinationPractice": [
      {
        "question": "Which should be used for effective routine handwashing?",
        "answer": "Soap and clean water",
        "explanation": "Soap and clean water help remove dirt and germs."
      },
      {
        "question": "Throwing rubbish into a proper bin is an example of _____.",
        "answer": "Good sanitation",
        "explanation": "Correct waste disposal keeps surroundings cleaner."
      }
    ]
  },
  {
    "week": 4,
    "title": "Food, Nutrition and Balanced Diet",
    "objectives": [
      "Define nutrition and balanced diet.",
      "Identify major classes of food.",
      "Explain the importance of safe food and clean water."
    ],
    "introduction": "Food provides energy, supports growth and helps the body repair itself. Good nutrition involves eating a variety of foods in suitable amounts.",
    "sections": [
      {
        "heading": "Classes of Food",
        "content": "Carbohydrates provide energy; proteins support growth and repair; fats provide stored energy and help the body use some vitamins; vitamins and minerals support body functions; water is essential for many body processes; fibre supports digestion."
      },
      {
        "heading": "Balanced Diet",
        "content": "A balanced diet contains a suitable variety of foods from different groups. Examples of locally available foods include rice, yam, beans, eggs, fish, vegetables, fruits and groundnuts."
      },
      {
        "heading": "Food Hygiene",
        "content": "Wash hands before handling food, wash fruits and vegetables with safe water, keep food covered and store it properly. Avoid food that appears spoiled."
      },
      {
        "heading": "Healthy Choices",
        "content": "Eat a variety of foods, drink safe water and avoid relying on only one type of food. Individual needs may differ, so seek guidance from a trusted adult or health professional when needed."
      }
    ],
    "workedExamples": [
      {
        "question": "Which class of food is especially important for growth and repair?",
        "solution": "Protein."
      },
      {
        "question": "Give two examples of foods that provide vitamins and minerals.",
        "solution": "Oranges and leafy vegetables."
      }
    ],
    "keyTerms": [
      "Nutrition",
      "Balanced diet",
      "Carbohydrate",
      "Protein",
      "Fat",
      "Vitamin",
      "Mineral",
      "Fibre"
    ],
    "classExercises": [
      "Name three classes of food. Answer: Carbohydrates, proteins and vitamins (among others).",
      "What is a balanced diet? Answer: A diet containing a suitable variety of foods in appropriate amounts.",
      "State two food hygiene practices. Answer: Wash hands before handling food and keep food covered."
    ],
    "commonMistakes": [
      "Thinking one food contains every nutrient in the right amount.",
      "Assuming clean-looking food is always safely stored."
    ],
    "summary": "A varied balanced diet supports energy, growth and health. Safe food handling and clean water are also important.",
    "examinationPractice": [
      {
        "question": "Which nutrient group supports growth and repair?",
        "answer": "Protein",
        "explanation": "Proteins help build and repair body tissues."
      },
      {
        "question": "Why should food be covered?",
        "answer": "To protect it from dirt, insects and contamination",
        "explanation": "Covered food is less exposed to contamination."
      }
    ]
  },
  {
    "week": 5,
    "title": "Good Posture and Body Movement",
    "objectives": [
      "Explain posture.",
      "Identify examples of good posture.",
      "Describe safe movement when sitting, standing and carrying school items."
    ],
    "introduction": "Posture is the way we hold our bodies when sitting, standing or moving. Good posture supports comfortable movement.",
    "sections": [
      {
        "heading": "Standing and Sitting",
        "content": "When standing, keep the body comfortably upright and avoid slouching. When sitting, support the back where possible, keep feet supported and avoid remaining in one position for too long."
      },
      {
        "heading": "Lifting and Carrying",
        "content": "Ask for help with heavy or awkward objects. Keep loads close to the body, avoid twisting suddenly and use both straps of a backpack when appropriate."
      },
      {
        "heading": "Movement Skills",
        "content": "Walking, running, jumping, turning and balancing are basic movement skills. Practise them in a clear space and follow instructions."
      },
      {
        "heading": "Healthy Habits",
        "content": "Take movement breaks during long periods of sitting, arrange study materials comfortably and tell a teacher or trusted adult if an activity causes ongoing discomfort."
      }
    ],
    "workedExamples": [
      {
        "question": "Why is it useful to take breaks from sitting?",
        "solution": "Changing position and moving gently helps avoid staying in one posture for too long."
      },
      {
        "question": "What should a learner do with an object that is too heavy?",
        "solution": "Ask a responsible adult for help rather than trying to lift it alone."
      }
    ],
    "keyTerms": [
      "Posture",
      "Movement",
      "Balance",
      "Coordination",
      "Backpack",
      "Ergonomics"
    ],
    "classExercises": [
      "Define posture. Answer: The way the body is held when sitting, standing or moving.",
      "State two examples of good sitting habits. Answer: Support the back and keep feet supported.",
      "What should you do if an object is too heavy? Answer: Ask for help."
    ],
    "commonMistakes": [
      "Slouching for long periods.",
      "Trying to lift heavy objects without help."
    ],
    "summary": "Good posture and safe movement habits support comfort and help learners move confidently.",
    "examinationPractice": [
      {
        "question": "Posture describes how we hold our _____.",
        "answer": "Body",
        "explanation": "Posture is body position when sitting, standing or moving."
      },
      {
        "question": "What should you do before lifting a heavy object?",
        "answer": "Ask for adult help",
        "explanation": "Heavy or awkward objects should not be lifted alone."
      }
    ]
  },
  {
    "week": 6,
    "title": "Games, Sports and Athletics",
    "objectives": [
      "Explain games, sports and athletics.",
      "Identify basic movement skills used in games.",
      "Demonstrate respect and teamwork."
    ],
    "introduction": "Games and sports provide opportunities to practise movement, follow rules, cooperate and enjoy physical activity.",
    "sections": [
      {
        "heading": "Games and Sports",
        "content": "A game is an organised activity with rules and a goal. Sport is structured physical activity that may involve skill, practice and competition. Athletics includes events such as running, jumping and throwing."
      },
      {
        "heading": "Basic Skills",
        "content": "Running, jumping, throwing, catching, kicking and balancing are used in many activities. Skills should be practised with suitable equipment and supervision."
      },
      {
        "heading": "Rules and Officials",
        "content": "Rules help keep activities fair and organised. Teachers or officials explain rules, guide play and help resolve disagreements."
      },
      {
        "heading": "Teamwork and Fair Play",
        "content": "Encourage teammates, take turns, respect opponents, accept decisions calmly and congratulate others. Winning is not more important than safety and respect."
      }
    ],
    "workedExamples": [
      {
        "question": "Name two athletics activities.",
        "solution": "Running and jumping."
      },
      {
        "question": "Why do games have rules?",
        "solution": "Rules make play organised, fair and safer."
      }
    ],
    "keyTerms": [
      "Game",
      "Sport",
      "Athletics",
      "Teamwork",
      "Fair play",
      "Official"
    ],
    "classExercises": [
      "Name three basic movement skills. Answer: Running, jumping and throwing (or catching/kicking).",
      "State two examples of fair play. Answer: Respect opponents and follow the rules.",
      "What is the role of an official? Answer: To help apply the rules and organise fair play."
    ],
    "commonMistakes": [
      "Arguing or insulting others after a decision.",
      "Using unsuitable equipment or playing in an unsafe area."
    ],
    "summary": "Games, sports and athletics develop movement skills, cooperation and respect when played fairly and safely.",
    "examinationPractice": [
      {
        "question": "Running and jumping are examples of _____.",
        "answer": "Athletics activities",
        "explanation": "Athletics includes track and field events."
      },
      {
        "question": "Respecting opponents is part of _____.",
        "answer": "Fair play",
        "explanation": "Fair play means following rules and treating others respectfully."
      }
    ]
  },
  {
    "week": 7,
    "title": "Safety Rules in Physical Activities",
    "objectives": [
      "Identify common risks in physical activities.",
      "State safety rules for games and sports.",
      "Explain the importance of supervision."
    ],
    "introduction": "Safety rules reduce avoidable risks during exercise, games and sports. Every learner has a responsibility to follow them.",
    "sections": [
      {
        "heading": "Before Activity",
        "content": "Use a suitable playing area, check that equipment is in good condition, wear appropriate clothing and footwear, and listen to instructions."
      },
      {
        "heading": "During Activity",
        "content": "Follow rules, use equipment correctly, avoid pushing or dangerous behaviour, respect personal space and stop when the teacher gives a signal."
      },
      {
        "heading": "After Activity",
        "content": "Return equipment properly, cool down as directed, drink safe water and report any problem to the teacher."
      },
      {
        "heading": "Supervision",
        "content": "Teachers and responsible adults organise activities and respond to concerns. Learners should not attempt unfamiliar or risky activities without supervision."
      }
    ],
    "workedExamples": [
      {
        "question": "What should learners do when the teacher signals stop?",
        "solution": "Stop the activity and listen for instructions."
      },
      {
        "question": "Why should equipment be checked before a game?",
        "solution": "To identify damage or hazards before use."
      }
    ],
    "keyTerms": [
      "Safety",
      "Hazard",
      "Supervision",
      "Protective equipment",
      "Playing area"
    ],
    "classExercises": [
      "State three safety rules before a game. Answer: Check the area, check equipment and listen to instructions.",
      "What should you do if equipment is damaged? Answer: Do not use it; report it to the teacher.",
      "Why is supervision important? Answer: It helps activities stay organised and concerns receive attention."
    ],
    "commonMistakes": [
      "Ignoring instructions because a game is exciting.",
      "Continuing to use damaged equipment."
    ],
    "summary": "Safe participation requires preparation, rule-following, suitable equipment and adult supervision.",
    "examinationPractice": [
      {
        "question": "Damaged sports equipment should be _____.",
        "answer": "Reported and not used",
        "explanation": "Damaged equipment may create avoidable risks."
      },
      {
        "question": "Who should guide organised school sports activities?",
        "answer": "A teacher or responsible adult",
        "explanation": "Supervision helps keep activities safe and orderly."
      }
    ]
  },
  {
    "week": 8,
    "title": "Basic First Aid and Seeking Help",
    "objectives": [
      "Explain first aid at a basic level.",
      "Identify responsible actions when someone is unwell or hurt.",
      "Know when to seek adult and professional help."
    ],
    "introduction": "First aid is the immediate help given to someone who is suddenly unwell or hurt while appropriate further help is arranged.",
    "sections": [
      {
        "heading": "Stay Calm and Get Help",
        "content": "Tell a teacher, school staff member or responsible adult immediately. If the situation appears serious, the adult should contact local emergency or medical services."
      },
      {
        "heading": "Keep the Area Safe",
        "content": "Do not crowd the person. Keep the area clear and follow the adult's instructions. Do not move someone who may have a serious injury unless there is an immediate danger and an adult directs it."
      },
      {
        "heading": "Simple Support",
        "content": "For a minor concern, a trained adult may provide basic care using suitable first-aid supplies. Learners should not give medicines or attempt procedures they have not been trained to do."
      },
      {
        "heading": "Prevention",
        "content": "Follow sports rules, use suitable equipment, keep walkways clear and report hazards early."
      }
    ],
    "workedExamples": [
      {
        "question": "A classmate suddenly feels unwell during a lesson. What should you do?",
        "solution": "Tell the teacher or responsible adult immediately and follow their instructions."
      },
      {
        "question": "Should a learner give medicine to another learner?",
        "solution": "No. Tell a responsible adult; medicines should only be handled with appropriate adult and health-professional guidance."
      }
    ],
    "keyTerms": [
      "First aid",
      "Emergency",
      "Responsible adult",
      "First-aid kit",
      "Prevention"
    ],
    "classExercises": [
      "What is first aid? Answer: Immediate basic help given while further help is arranged.",
      "Name the first person you should alert if a classmate is hurt at school. Answer: The teacher or responsible adult.",
      "Should learners give medicines to classmates? Answer: No."
    ],
    "commonMistakes": [
      "Trying to treat a serious problem without adult help.",
      "Giving someone medicine without appropriate adult and professional guidance."
    ],
    "summary": "Stay calm, alert a responsible adult, keep the area safe and follow instructions. Serious concerns need professional help.",
    "examinationPractice": [
      {
        "question": "What is the first sensible action when a learner becomes unwell at school?",
        "answer": "Tell a teacher or responsible adult",
        "explanation": "An adult can assess the situation and arrange appropriate help."
      },
      {
        "question": "Should learners attempt procedures they have not been trained to do?",
        "answer": "No",
        "explanation": "They should get adult help and follow instructions."
      }
    ]
  },
  {
    "week": 9,
    "title": "Common Communicable Diseases and Prevention",
    "objectives": [
      "Explain communicable disease.",
      "Identify ways infections can spread.",
      "Describe general prevention habits."
    ],
    "introduction": "Communicable diseases are illnesses that can spread from one person to another, or through contaminated food, water, objects or vectors.",
    "sections": [
      {
        "heading": "How Diseases Spread",
        "content": "Some infections spread through droplets from coughing or sneezing, contaminated food or water, direct contact, shared objects or insects such as mosquitoes. Different diseases spread in different ways."
      },
      {
        "heading": "Prevention",
        "content": "Wash hands, use safe water, handle food hygienically, keep surroundings clean, cover coughs and sneezes with a tissue or elbow, and follow public-health advice."
      },
      {
        "heading": "When Someone Is Unwell",
        "content": "Tell a trusted adult and seek advice from a qualified health professional. Avoid teasing or blaming people who are ill."
      },
      {
        "heading": "Community Protection",
        "content": "Clean surroundings, appropriate vaccination programmes, health education and access to safe water help protect communities."
      }
    ],
    "workedExamples": [
      {
        "question": "Give one way to reduce the spread of germs through hands.",
        "solution": "Wash hands with soap and clean water."
      },
      {
        "question": "Why should a learner tell an adult when feeling unwell?",
        "solution": "An adult can help arrange appropriate care and reduce risks to others."
      }
    ],
    "keyTerms": [
      "Communicable disease",
      "Infection",
      "Prevention",
      "Contamination",
      "Vector",
      "Vaccination"
    ],
    "classExercises": [
      "Define communicable disease. Answer: An illness that can spread between people or through other routes.",
      "State three general prevention habits. Answer: Handwashing, safe water and good food hygiene.",
      "Why should sick people not be mocked? Answer: Illness is not a reason for blame; people deserve care and respect."
    ],
    "commonMistakes": [
      "Assuming every disease spreads in the same way.",
      "Sharing unverified health advice instead of asking a qualified professional."
    ],
    "summary": "Different communicable diseases spread in different ways. Hygiene, safe water, public-health measures and respectful care help protect people.",
    "examinationPractice": [
      {
        "question": "A mosquito can act as a ____ for some diseases.",
        "answer": "Vector",
        "explanation": "A vector carries an infectious agent between hosts."
      },
      {
        "question": "Name one general way to reduce the spread of infection.",
        "answer": "Handwashing with soap and clean water",
        "explanation": "Handwashing helps remove germs from hands."
      }
    ]
  },
  {
    "week": 10,
    "title": "First-Term P.H.E. Revision",
    "objectives": [
      "Review the main PHE topics covered during the term.",
      "Use health and fitness vocabulary correctly.",
      "Apply safety and hygiene knowledge to everyday situations."
    ],
    "introduction": "This week reviews the term's topics and prepares learners for the end-of-term assessment.",
    "sections": [
      {
        "heading": "Topics to Revise",
        "content": "Revise physical fitness; types of exercise; personal hygiene and sanitation; food and nutrition; posture and movement; games and athletics; sports safety; basic first aid; and communicable disease prevention."
      },
      {
        "heading": "Practical Review",
        "content": "Practise basic movement skills only in a suitable supervised area. Explain the rules of a familiar game and identify ways to make participation safer."
      },
      {
        "heading": "Health Review",
        "content": "Explain handwashing, balanced eating, safe water, rest, good posture and how to seek adult help when someone is unwell."
      }
    ],
    "workedExamples": [
      {
        "question": "What is one way to show fair play?",
        "solution": "Respect the rules and other players."
      },
      {
        "question": "What should you do if a classmate becomes unwell?",
        "solution": "Tell a teacher or responsible adult."
      }
    ],
    "keyTerms": [
      "Revision",
      "Well-being",
      "Fair play",
      "Hygiene",
      "Safety"
    ],
    "classExercises": [
      "Name three components of fitness. Answer: Endurance, strength and flexibility (among others).",
      "State two food hygiene practices. Answer: Wash hands before handling food and keep food covered.",
      "Give one example of fair play. Answer: Respect opponents and follow rules."
    ],
    "commonMistakes": [
      "Thinking physical fitness is only about speed or strength.",
      "Confusing first aid with replacing professional medical care."
    ],
    "summary": "PHE combines movement education and health knowledge. Safe habits, respect and suitable activity support well-being.",
    "examinationPractice": [
      {
        "question": "Which topic teaches how to keep the body and surroundings clean?",
        "answer": "Personal hygiene and sanitation",
        "explanation": "These habits help protect individual and community health."
      },
      {
        "question": "What should learners do when a sports activity becomes unsafe?",
        "answer": "Stop and alert the teacher",
        "explanation": "The teacher can make the activity safe or end it."
      }
    ]
  },
  {
    "week": 11,
    "title": "Guided P.H.E. Revision and Practice",
    "objectives": [
      "Practise explaining key PHE ideas.",
      "Apply safety and hygiene knowledge to familiar situations."
    ],
    "introduction": "Use this week to practise healthy-living decisions and review movement, games and safety rules.",
    "sections": [
      {
        "heading": "Fitness and Movement",
        "content": "Recall the components of fitness and explain how suitable activities develop movement skills."
      },
      {
        "heading": "Healthy Living",
        "content": "Review personal hygiene, sanitation, balanced nutrition, rest and safe water."
      },
      {
        "heading": "Safety and Respect",
        "content": "Explain fair play, sports safety and the importance of telling a responsible adult when someone is unwell."
      }
    ],
    "workedExamples": [
      {
        "question": "What should you do if a classmate becomes unwell during a game?",
        "solution": "Stop the activity and tell the teacher or responsible adult."
      },
      {
        "question": "Give one example of fair play.",
        "solution": "Respect the rules and other players."
      }
    ],
    "keyTerms": [
      "Revision",
      "Well-being",
      "Fair play",
      "Hygiene",
      "Safety"
    ],
    "classExercises": [
      "Name three components of fitness. Answer: Endurance, strength and flexibility (among others).",
      "State two food hygiene practices. Answer: Wash hands before handling food and keep food covered.",
      "Give one example of fair play. Answer: Respect opponents and follow rules."
    ],
    "commonMistakes": [
      "Thinking physical fitness is only about speed or strength.",
      "Confusing first aid with replacing professional medical care."
    ],
    "summary": "PHE combines movement education and health knowledge. Safe habits, respect and suitable activity support well-being.",
    "examinationPractice": [
      {
        "question": "Which topic teaches how to keep the body and surroundings clean?",
        "answer": "Personal hygiene and sanitation",
        "explanation": "These habits help protect individual and community health."
      },
      {
        "question": "Who should a learner alert when someone is unwell at school?",
        "answer": "A teacher or responsible adult",
        "explanation": "An adult can arrange appropriate support."
      }
    ]
  },
  {
    "week": 12,
    "title": "First-Term P.H.E. Assessment",
    "objectives": [
      "Demonstrate understanding of PHE topics.",
      "Apply safety, hygiene and nutrition knowledge.",
      "Reflect on areas for further learning."
    ],
    "introduction": "This assessment checks knowledge of physical fitness, safe activity, hygiene, nutrition, movement, games and health protection.",
    "sections": [
      {
        "heading": "Assessment Areas",
        "content": "Questions may cover fitness components, exercise types, hygiene, balanced diet, posture, games, safety, first aid principles and communicable disease prevention."
      },
      {
        "heading": "Answering Well",
        "content": "Read each question carefully, use clear health vocabulary and give practical examples where requested."
      },
      {
        "heading": "Learning from Feedback",
        "content": "Review corrections, ask questions about unclear answers and continue practising safe, enjoyable activity."
      }
    ],
    "workedExamples": [
      {
        "question": "State one benefit of regular physical activity.",
        "solution": "It supports fitness and helps develop coordination."
      },
      {
        "question": "What should you do when someone is hurt during school sports?",
        "solution": "Alert the teacher or responsible adult and follow their instructions."
      }
    ],
    "keyTerms": [
      "Assessment",
      "Healthy habits",
      "Safety rules",
      "Feedback"
    ],
    "classExercises": [
      "Define a balanced diet. Answer: A suitable variety of foods from different groups in appropriate amounts.",
      "State two safety rules for sports. Answer: Use suitable equipment and follow instructions.",
      "Give two ways to prevent the spread of infection. Answer: Handwashing and safe food/water practices."
    ],
    "commonMistakes": [
      "Rushing through questions without reading them carefully.",
      "Giving medical advice instead of explaining that a responsible adult or health professional should be contacted."
    ],
    "summary": "Assessment checks understanding and identifies areas for further learning. Safe choices and respectful behaviour remain important beyond the classroom.",
    "examinationPractice": [
      {
        "question": "The ability to continue an activity over time is called _____.",
        "answer": "Endurance",
        "explanation": "Endurance is one component of physical fitness."
      },
      {
        "question": "Who should a learner alert when someone is unwell at school?",
        "answer": "A teacher or responsible adult",
        "explanation": "An adult can arrange appropriate support."
      }
    ]
  }
];
})();
